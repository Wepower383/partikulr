# Partikulr v1.6.1

A sacred simulation chamber.

## Features
- Voice-responsive particles
- Vacuum and Dream modes
- Hidden glyphs and lore

Crafted by WePower for the seekers.